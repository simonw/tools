
/* comment: This has 5 physical lines of code. */

class Test {
  static void Main() {
    System.Console.WriteLine("Hello, World (in C#)");
  }
}
